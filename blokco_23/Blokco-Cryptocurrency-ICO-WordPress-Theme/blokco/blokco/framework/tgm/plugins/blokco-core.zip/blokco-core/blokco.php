<?php
/* 
 * Plugin Name: Blokco Core
 * Plugin URI:  https://www.imithemes.com
 * Description: Create Post Types, Meta Boxes for Blokco Theme
 * Author:      imithemes
 * Version:     1.9
 * Author URI:  https://www.imithemes.com
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Copyright:   (c) 2021 imithemes. All rights reserved
 * Text Domain: blokco-core
 * Domain Path: /language
 */

// Do not allow direct access to this file.
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
$path = plugin_dir_path( __FILE__ );
define('BLOKCO_CORE__PLUGIN_PATH', plugin_dir_path(__FILE__));
define('BLOKCO_CORE__PLUGIN_URL', plugin_dir_url(__FILE__));
/* CUSTOM POST TYPES
================================================== */
require_once BLOKCO_CORE__PLUGIN_PATH . 'post-type.class.php';
require_once BLOKCO_CORE__PLUGIN_PATH .'post-types-config.php';

/* MEGAMENU
================================================== */
require_once BLOKCO_CORE__PLUGIN_PATH . 'megamenu/imi-megamenu.php';

/* IMI ADMIN INCLUDES
================================================== */
require_once BLOKCO_CORE__PLUGIN_PATH . 'includes.php';
/* SET LANGUAGE FILE FOLDER
=================================================== */
add_action('after_setup_theme', 'blokco_core_setup');
function blokco_core_setup() {
    load_theme_textdomain('blokco-core', plugin_dir_path( __FILE__ ) . '/language');
}