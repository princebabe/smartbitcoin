<?php
//Remove Redux Framework Notices
function blokco_remove_redux_notices()
{ // Be sure to rename this function to something more unique
    if (class_exists('ReduxFrameworkPlugin')) {
        remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::get_instance(), 'plugin_metalinks'), null, 2);
    }
    if (class_exists('ReduxFrameworkPlugin')) {
        remove_action('admin_notices', array(ReduxFrameworkPlugin::get_instance(), 'admin_notices'));
    }
}
add_action('init', 'blokco_remove_redux_notices');

if (class_exists('Woocommerce')) {
    // Remove Woocommerce redirect setup page
    if (!function_exists('remove_class_filters')) {
        function remove_class_filters($tag, $class, $method)
        {
            $filters = $GLOBALS['wp_filter'][$tag];
            if (empty($filters)) {
                return;
            }
            foreach ($filters as $priority => $filter) {
                foreach ($filter as $identifier => $function) {
                    if (is_array($function) and is_a($function['function'][0], $class) and $method === $function['function'][1]) {
                        remove_filter(
                            $tag,
                            array($function['function'][0], $method),
                            $priority
                        );
                    }
                }
            }
        }
    }
    add_action('admin_init', 'disable_shop_redirect', 0);
    function disable_shop_redirect()
    {
        remove_class_filters(
            'admin_init',
            'WC_Admin',
            'admin_redirects'
        );
    }
}

// Scripts Defer Function
function blokco_add_defer_attribute($tag, $handle) {
   // add script handles to the array below
   $scripts_to_defer = array('my-js-handle');
   
   foreach($scripts_to_defer as $defer_script) {
      if ($defer_script === $handle) {
         return str_replace(' src', ' defer="defer" src', $tag);
      }
   }
   return $tag;
}
add_filter('script_loader_tag', 'blokco_add_defer_attribute', 10, 2);

require_once BLOKCO_CORE__PLUGIN_PATH . 'meta-boxes/meta-box/meta-box.php';
require_once BLOKCO_CORE__PLUGIN_PATH . 'meta-boxes/meta-box-show-hide/meta-box-show-hide.php';
require_once BLOKCO_CORE__PLUGIN_PATH . 'meta-boxes/meta-box-conditional-logic/meta-box-conditional-logic.php';
require_once BLOKCO_CORE__PLUGIN_PATH . 'meta-boxes/meta-box-group/meta-box-group.php';
require_once BLOKCO_CORE__PLUGIN_PATH . 'meta-boxes/meta-box-tabs/meta-box-tabs.php';
require_once BLOKCO_CORE__PLUGIN_PATH . 'meta-boxes/meta-box-columns/meta-box-columns.php';
require_once BLOKCO_CORE__PLUGIN_PATH . 'meta-boxes/mb-term-meta/mb-term-meta.php';
if (!class_exists('ReduxFramework')) {
    include_once BLOKCO_CORE__PLUGIN_PATH . 'imi-admin/theme-options/ReduxCore/framework.php';
}
if (is_admin()) {
    include_once BLOKCO_CORE__PLUGIN_PATH . 'imi-admin/admin.php';
}
//Widgets
require_once BLOKCO_CORE__PLUGIN_PATH . 'widgets/recent_posts.php';
require_once BLOKCO_CORE__PLUGIN_PATH . 'widgets/tabs_widget.php';
require_once BLOKCO_CORE__PLUGIN_PATH . 'widgets/flickr_widget.php';
