<?php
//Plugin's folder should always have this file.